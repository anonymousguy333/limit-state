# LIMIT//STATE

Production-ready static build of an interactive, educational Porsche 911 GT3 RS (992) vehicle-dynamics experience.

## Run locally

From the project root:

```powershell
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Included in the release archive

- `dist/` — deployable static site
- `ASSET-MANIFEST.md` — original-asset and engineering-source record

All interactive outputs are visibly labelled documented, derived, or simulated as appropriate. No third-party photography, video, logos, or models are distributed with this build.
