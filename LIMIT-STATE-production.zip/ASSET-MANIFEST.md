# LIMIT//STATE — source & asset manifest

## Visual assets

| Asset | Source / usage basis | Where used |
| --- | --- | --- |
| All vehicle, airflow, brake, track and telemetry illustrations | Original CSS/SVG graphics authored for this project. They are deliberately abstract educational diagrams, not a Porsche CAD model. | Entire experience |
| Typography | System font stack — no external font file required. | Entire experience |

No third-party photography, video, logos, 3D models, or downloaded media are included.

## Documented GT3 RS information

- [Porsche 911 GT3 RS product page](https://www.porsche.com/international/models/911/911-gt3-rs/911-gt3-rs/) — active aero, DRS, high-revving naturally aspirated engine and rear-axle steering.
- [Porsche Newsroom, 2022 GT3 RS premiere](https://newsroom.porsche.com/en/2022/products/porsche-911-gt3-rs-world-premiere-29177.html) — 4.0L naturally aspirated engine, 525 PS, active aerodynamics, DRS, 409 kg at 200 km/h and 860 kg at 285 km/h.
- [Porsche GT3 RS technical data (MY 2022)](https://newsroom.porsche.com/dam/jcr%3A1d390f77-93c3-49c0-89c7-634f5f02b26a/S22_3515_en.pdf) — rear-wheel drive, 7-speed PDK, PTV Plus, PASM, rear-axle steering and suspension specifications.

## Methodology

Documented facts are visibly presented as documented. Numbers produced by controls are labelled **SIMULATED**. The mass chapter’s axle-load calculation is labelled **DERIVED** and uses a simple two-axle load-transfer approximation. None of the models represents Porsche’s proprietary software, vehicle calibration, tire model, lap-time model, or crash prediction.
